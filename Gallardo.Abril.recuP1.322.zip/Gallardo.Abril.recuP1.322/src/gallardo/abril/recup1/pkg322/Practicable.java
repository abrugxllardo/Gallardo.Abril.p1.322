
package gallardo.abril.recup1.pkg322;


public interface Practicable {
    void practicarEnPareja();
}
