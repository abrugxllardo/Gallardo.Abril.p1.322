
package gallardo.abril.recup1.pkg322;


public class Juvenil extends Jugador implements Practicable{
    private boolean tieneTutor;
    
    public Juvenil(String nombre, int ranking, Superficie superficie, boolean tieneTutor){
        super(nombre, ranking, superficie);
        this.tieneTutor = tieneTutor;      
    }

    public boolean validarTutor(){
        if(tieneTutor){
            return true;
        }
        return false;
    }
    
    @Override
    public void practicarEnPareja() {
        System.out.printf(getNombre() + " -juvenil- practica en pareja. Tutor deportivo:" + validarTutor());
    }


    @Override
    public String toString() {
    return "Juvenil - " + super.toString() + " - Tiene tutor: " + validarTutor();
    }
    
}
