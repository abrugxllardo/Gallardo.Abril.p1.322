
package gallardo.abril.recup1.pkg322;

public class Doblista extends Jugador implements Sacable, Practicable {

    private int indiceCoordinacion;
    private int MIN = 1;
    private  int MAX = 10;


    public Doblista(String nombre, int ranking, Superficie superficie, int indiceCoordinacion) {
        super(nombre, ranking, superficie);
        this.indiceCoordinacion = indiceCoordinacion;
    }

    public int getIndiceCoordinacion(){
        return indiceCoordinacion; 
    }

    public void validarIndiceCoordinacion(){
        if(indiceCoordinacion < MIN || indiceCoordinacion > MAX){
            throw new IllegalArgumentException("indice invalido");
        }
    }
    
    @Override
    public void sacar(){
    validarIndiceCoordinacion();
    System.out.printf(getNombre() + " -doblista- Sacando.. Indice de coordinacion: " + getIndiceCoordinacion());
    }


    @Override
    public void practicarEnPareja(){
        validarIndiceCoordinacion();
        System.out.printf( getNombre() + " -doblista- practica en pareja.. Indice de coordinacion: " + indiceCoordinacion);
    }


    @Override
    public String toString() {
        return "Doblista - " + super.toString() + " - Indice de coordinacion: " + getIndiceCoordinacion();
    }
}

