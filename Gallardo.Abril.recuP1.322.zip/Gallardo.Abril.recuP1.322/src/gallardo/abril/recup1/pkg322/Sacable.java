
package gallardo.abril.recup1.pkg322;


public interface Sacable {
    void sacar();
}
