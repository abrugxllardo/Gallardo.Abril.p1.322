
package gallardo.abril.recup1.pkg322;


public class GallardoAbrilRecuP1322 {

    
    public static void main(String[] args) {
        Torneo torneo = new Torneo();

        try {
            torneo.agregarJugador(new Singlista("David Nalbandian", 3, Superficie.CEMENTO, 200));
            torneo.agregarJugador(new Doblista("Bob y Mike", 12, Superficie.POLVO, 8));
            torneo.agregarJugador(new Juvenil("Juan Perez", 150, Superficie.CESPED, true));
            
            // Para que salte la excepcion del jugador duplicado
            torneo.agregarJugador(new Singlista("David Nalbandian", 3, Superficie.CEMENTO, 198));
        } catch (JugadorDuplicadoException ex) {
            System.out.println("Error: " + ex.getMessage());
        }


        System.out.println();
        torneo.mostrarJugadores();

        System.out.println();
        torneo.sacar(); 

        System.out.println();
        torneo.practicarEnPareja(); 

        System.out.println();
        torneo.filtrarPorSuperficie(Superficie.CEMENTO);

        System.out.println();
        torneo.resumenPorTipo();
    }
 
}
