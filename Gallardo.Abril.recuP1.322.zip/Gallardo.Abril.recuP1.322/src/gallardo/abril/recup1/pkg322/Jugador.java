
package gallardo.abril.recup1.pkg322;


public abstract class Jugador {
    private String nombre;
    private int ranking;
    private Superficie superficie;


    public Jugador(String nombre, int ranking, Superficie superficie) {
        this.nombre = nombre;
        this.ranking = ranking;
        this.superficie = superficie;
    }


    public String getNombre(){ 
        return nombre; 
    }
    
    public int getRanking(){
        return ranking;
    }
    
    public Superficie getSuperficie(){ 
        return superficie; 
    }

    @Override
    public boolean equals(Object o) {
        if(this == o){
            return true;
        }
        
        if(!(o instanceof Jugador)){
            return false;
        }
        
        Jugador j = (Jugador) o;
       
        return nombre.equalsIgnoreCase(j.nombre) && ranking == j.ranking;
    }

    protected String mostrar(){
        StringBuilder sb = new StringBuilder();
        sb.append("nombre: ").append(nombre).append(" - Ranking: ").append(ranking).append(" - Superficie: ").append(superficie);
        
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return this.mostrar();
    }

}
