package gallardo.abril.recup1.pkg322;

public enum Superficie {
    POLVO,
    CESPED,
    CEMENTO
}
