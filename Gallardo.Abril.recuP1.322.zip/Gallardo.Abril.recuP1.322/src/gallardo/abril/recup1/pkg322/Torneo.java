
package gallardo.abril.recup1.pkg322;

import java.util.ArrayList;
import java.util.List;


public class Torneo {
    private List<Jugador> jugadores = new ArrayList<>();

    public void agregarJugador(Jugador jugador) throws JugadorDuplicadoException {
        if(jugador == null){
            throw new IllegalArgumentException("Proyecto nulo");
        }
        
        if (jugadores.contains(jugador)) {
            throw new JugadorDuplicadoException("Ya existe un jugador con el mismo nombre: " + jugador.getNombre());
        }
        
        jugadores.add(jugador);
    }
    
    public void validarListaJugadores(){
        if (jugadores.isEmpty()) {
            System.out.println("No hay jugadores registrados");
        }
    }
    
    public void mostrarJugadores() {
        validarListaJugadores();
        System.out.println("=== LISTA DE JUGADORES ===");
        for (Jugador j : jugadores) {
            System.out.println(j);
        }
    }
    
    public void sacar(){
        validarListaJugadores();
        for (Jugador j : jugadores) {
            if (j instanceof Sacable) {
                ((Sacable)j).sacar();
            } else {
                System.out.println("El Jugador '" + j.getNombre() + "' no puede sacar");
            }
        }
    }
    
    public void practicarEnPareja(){
        validarListaJugadores();
        for (Jugador j : jugadores) {
            if (j instanceof Sacable) {
                ((Sacable)j).sacar();
            } else {
                System.out.println("El jugador '" + j.getNombre() + "' no puede jugar en pareja");
            }
        }
    }
    
    public List<Jugador> filtrarPorSuperficie(Superficie superficie) {
        List<Jugador> jugadoresPorSuperficie = new ArrayList<>();

        for (Jugador j : jugadores) {
            if (j.getSuperficie() == superficie) {
                jugadoresPorSuperficie.add(j);
            }
        }


        if (jugadoresPorSuperficie.isEmpty()) {
            System.out.println("No se encontraron jugadores para superficie: " + superficie);
        } else {
            
            System.out.println("Jugadores de superficie:  " + superficie + ":");
            
            for (Jugador j : jugadoresPorSuperficie) {
                System.out.println(j.toString());
            }
        }
        return jugadoresPorSuperficie;
    }
    
    
    public void resumenPorTipo(){
 
        for (Jugador j : jugadores) {
            if (j instanceof Singlista){
                System.out.println("Singlistas: " + j.toString());
            }else if (j instanceof Doblista){
                System.out.println("Doblistas: " + j.toString());
            }else if (j instanceof Juvenil){
                System.out.println("Juveniles: " + j.toString());
            }
        }
    }
}
    

