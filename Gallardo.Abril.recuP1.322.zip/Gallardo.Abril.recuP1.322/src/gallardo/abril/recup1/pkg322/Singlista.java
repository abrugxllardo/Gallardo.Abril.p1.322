
package gallardo.abril.recup1.pkg322;


public class Singlista extends Jugador implements Sacable{
    private double velocidadSaque; 


    public Singlista(String nombre, int ranking, Superficie superficie, int velocidadSaque) {
        super(nombre, ranking, superficie);
        this.velocidadSaque = velocidadSaque;
    }


    public double getVelocidadSaque(){ 
        return velocidadSaque; 
    }


    @Override
    public void sacar() {
        System.out.printf(getNombre() + " -Singlista- sacando.. Velocidad de saque: " + getVelocidadSaque());
    }


    @Override
    public String toString() {
        return "Singlista - " + super.toString() + "Velocidad de saque: " + getVelocidadSaque() + "/km";
    }
}

