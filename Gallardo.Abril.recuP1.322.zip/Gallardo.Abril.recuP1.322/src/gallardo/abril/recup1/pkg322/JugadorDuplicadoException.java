
package gallardo.abril.recup1.pkg322;

public class JugadorDuplicadoException extends Exception{
    public JugadorDuplicadoException(String mensaje){
        super(mensaje);
    }
}
