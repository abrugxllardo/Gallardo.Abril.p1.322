
package gallardo.abril.p1.pkg322;


public class AnalisisEstadistico extends Proyecto implements Actualizable{

    private TipoAnalisis tipo;

    public AnalisisEstadistico(String nombre, String equipo, EstadoProyecto estado, TipoAnalisis tipo) {
        super(nombre, equipo, estado);
        this.tipo = tipo;
    }

    @Override
    public void actualizarResultados() {
        System.out.println("Resultados del analisis " + getNombre() + " " + tipo + " actualizados correctamente");
    }
}


