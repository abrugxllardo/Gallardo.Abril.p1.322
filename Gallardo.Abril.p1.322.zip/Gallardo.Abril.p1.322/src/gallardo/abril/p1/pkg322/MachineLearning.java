
package gallardo.abril.p1.pkg322;


public class MachineLearning extends Proyecto implements Actualizable{
    private double precision;
    private final int MIN = 0;
    private final int MAX = 10;

    public MachineLearning(String nombre, String equipo, EstadoProyecto estado, double precision) {
        super(nombre, equipo, estado);
        this.precision = precision;
    }

    @Override
    public void actualizarResultados() {
        if(precision >= MIN && precision <= MAX){
            System.out.println("Resultados actualizados para MachineLearning" + getNombre() + "- Nueva precision: " + precision + "%");
        }
        else{
            throw new IllegalArgumentException("Presicion invalida");
        }
    }
}

