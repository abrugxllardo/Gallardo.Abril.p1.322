
package gallardo.abril.p1.pkg322;


public abstract class Proyecto {
    private String nombre;
    private String equipoResponsable;
    private EstadoProyecto estado;

    public Proyecto(String nombre, String equipoResponsable, EstadoProyecto estado) {
        this.nombre = nombre;
        this.equipoResponsable = equipoResponsable;
        this.estado = estado;
    }

    public String getNombre(){     
        return nombre; 
    }

    public String getEquipoResponsable(){
        return equipoResponsable;
    }  
   
    public EstadoProyecto getEstado(){
        return estado;
    }
    public void setEstado(EstadoProyecto estado){
        this.estado = estado; 
    }

    @Override
    public boolean equals(Object o){
        if(this == o){
            return true;
        }
        if(!(o instanceof Proyecto)){
            return false;
        }
        
        Proyecto proyecto = (Proyecto) o;
        return nombre.equalsIgnoreCase(proyecto.nombre) && equipoResponsable.equalsIgnoreCase(proyecto.equipoResponsable);
    }
    
    protected String mostrar(){
        StringBuilder sb = new StringBuilder();
        sb.append("nombre: ").append(nombre).append(" - Equipo: ").append(equipoResponsable).append(" - Estado: ").append(estado);
        
        return sb.toString();
    }
    
    @Override
    public String toString() {
        return this.mostrar();
    }
}

