
package gallardo.abril.p1.pkg322;


public class GallardoAbrilP1322 {

   
    public static void main(String[] args) {
    {
        Laboratorio lab = new Laboratorio();

        try {
            lab.agregarProyecto(new MachineLearning("Predicción Ventas", "Equipo A", EstadoProyecto.EN_DESARROLLO, 5.2));
            lab.agregarProyecto(new AnalisisEstadistico("Demografía Clientes", "Equipo B", EstadoProyecto.FINALIZADO, TipoAnalisis.DESCRIPTIVO));
            lab.agregarProyecto(new SistemaVisualizacion("Dashboard Ventas", "Equipo C", EstadoProyecto.ENTRENANDO_MODELO, 6));
            
            //Para lanzar la excepcion de proyecto duplicado
            lab.agregarProyecto(new MachineLearning("Predicción Ventas", "Equipo A", EstadoProyecto.EN_DESARROLLO, 5)); 
        } catch (ProyectoDuplicadoException e) {
            System.out.println("Error: " + e.getMessage());
        }

        lab.mostrarProyectos();
        System.out.println();

        lab.actualizarResultados();
        System.out.println();

        lab.actualizarEstadoProyectos(EstadoProyecto.FINALIZADO);
    }
}


}
    

