
package gallardo.abril.p1.pkg322;


public enum TipoAnalisis {
    DESCRIPTIVO,
    INFERENCIAL,
    PREDICTIVO;
}
