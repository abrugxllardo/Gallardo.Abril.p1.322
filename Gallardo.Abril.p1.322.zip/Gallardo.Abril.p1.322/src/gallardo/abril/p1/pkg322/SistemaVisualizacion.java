
package gallardo.abril.p1.pkg322;


public class SistemaVisualizacion extends Proyecto {
    private int cantidadGraficos;

    public SistemaVisualizacion(String nombre, String equipo, EstadoProyecto estado, int cantidadGraficos) {
        super(nombre, equipo, estado);        
        this.cantidadGraficos = cantidadGraficos;
    }

    public void validarGraficos(){
        if(cantidadGraficos <= 0){
            throw new IllegalArgumentException("Cantidad de graficos invalida");
        }
    }
}

