
package gallardo.abril.p1.pkg322;

import java.util.ArrayList;
import java.util.List;

  

public class Laboratorio {
    private List<Proyecto> proyectos = new ArrayList<>();

    public void agregarProyecto(Proyecto proyecto) throws ProyectoDuplicadoException {
        if(proyecto == null){
            throw new IllegalArgumentException("Proyecto nulo");
        }
        
        if (proyectos.contains(proyecto)) {
            throw new ProyectoDuplicadoException("Ya existe un proyecto con el mismo nombre: " + proyecto.getNombre() + " y equipo responsable: " + proyecto.getEquipoResponsable());
        }
        
        proyectos.add(proyecto);
    }
    public void validarListaProyectos(){
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados");
        }
    }
    
    public void validarModificacion(EstadoProyecto nuevoEstado){
        if (nuevoEstado == null) {
            System.out.println("No se realizo ninguna modificacion");
        }
    }
    
    public void mostrarProyectos() {
        validarListaProyectos();
        System.out.println("=== LISTA DE PROYECTOS ===");
        for (Proyecto p : proyectos) {
            System.out.println(p);
        }
    }

    public void actualizarResultados() {
        validarListaProyectos();
        for (Proyecto p : proyectos) {
            if (p instanceof Actualizable) {
                ((Actualizable)p).actualizarResultados();
            } else {
                System.out.println("El proyecto '" + p.getNombre() + "' no puede actualizar resultados directamente.");
            }
        }
    }

    public void actualizarEstadoProyectos(EstadoProyecto nuevoEstado) {
        validarModificacion(nuevoEstado);
        validarListaProyectos();

        int contador = 0;
        for (Proyecto p : proyectos) {
            if (p.getEstado() != nuevoEstado) {
                p.setEstado(nuevoEstado);
                System.out.println("Proyecto " + p.getNombre() + " actualizado a estado: " + nuevoEstado);
                contador++;
            }
        }

        if (contador == 0) {
            System.out.println("No se realizo ninguna modificacion");
        } else {
            System.out.println("Total de proyectos actualizados: " + contador);
        }
    }
}


