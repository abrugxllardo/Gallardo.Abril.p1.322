package gallardo.abril.p1.pkg322;


public interface Actualizable {
    void actualizarResultados();
}
